<?php // Silêncio.
